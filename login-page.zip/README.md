# tech-task

Install modules (if using ejs)
```
npm install
```

Run server
```
node index.js
```

Run server with automatic reloading after edits
```
nodemon index.js
```
